from django.db import models

# Create your models here.
class exercise_data(models.Model):
    id5 =models.IntegerField(primary_key=True)
    machine_id=models.CharField(max_length=1,blank=True)
    start_time=models.DateTimeField(blank=True)
    state=models.CharField(max_length=20,blank=True)
    end_time=models.DateTimeField(blank=True)