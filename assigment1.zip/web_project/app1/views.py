from django.shortcuts import render
from django.http import HttpResponse
from app1.forms import exercise_dataForm
from app1.models import exercise_data
# Create your views here.
def home(request):
    return render(request,'home.html')
def insert1(request):
    form=exercise_dataForm
    form1={'form':form}
    if request.method=='POST':
        form=exercise_dataForm(request.POST)
        if form.is_valid:
            form.save()
    return render(request,'exercise_data.html',form1)
def view1(request):
    res=exercise_data.objects.all()
    mydata={'data':res}
    return render(request,'exercise_dataview.html',mydata)
