from django import forms
from app1.models import exercise_data
class exercise_dataForm(forms.ModelForm):
    class Meta:
        model = exercise_data
        fields = '__all__'
